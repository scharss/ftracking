A Pen created at CodePen.io. You can find this one at https://codepen.io/edward1995/pen/ZoabOY.

 